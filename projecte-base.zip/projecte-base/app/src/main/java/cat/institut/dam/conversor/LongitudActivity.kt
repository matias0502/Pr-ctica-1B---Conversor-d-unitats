package cat.institut.dam.conversor

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

/**
 * Conversor de longitud: quilòmetre, milla i yarda.
 *
 * Estratègia: taula de factors DIRECTES (la de l'apartat 4.6 de l'enunciat).
 *   resultat = valor × FACTORS[origen][destí]
 * No es passa per la unitat base (km) perquè els factors de l'enunciat estan
 * arrodonits i, encadenant-ne dos, 1 mi → yd donava 1759.9956 en lloc de 1760.0000.
 */
class LongitudActivity : AppCompatActivity() {

    private lateinit var editValor: EditText
    private lateinit var radioGroupDe: RadioGroup
    private lateinit var radioGroupA: RadioGroup
    private lateinit var textResultat: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_longitud)

        editValor = findViewById(R.id.editValor)
        radioGroupDe = findViewById(R.id.radioGroupDe)
        radioGroupA = findViewById(R.id.radioGroupA)
        textResultat = findViewById(R.id.textResultat)

        findViewById<Button>(R.id.botoConvertir).setOnClickListener { convertir() }
    }

    private fun convertir() {
        val text = editValor.text.toString().trim()
        if (text.isEmpty()) {
            mostrarError(R.string.error_buid)
            return
        }

        val valor = text.toDoubleOrNull()
        if (valor == null) {
            mostrarError(R.string.error_numeric)
            return
        }

        val de = unitatOrigen(radioGroupDe.checkedRadioButtonId)
        val a = unitatDesti(radioGroupA.checkedRadioButtonId)
        if (de == null || a == null) {
            mostrarError(R.string.error_generic)
            return
        }

        if (de == a) {
            mostrarError(R.string.error_unitats)
            return
        }

        try {
            val resultat = calcular(valor, de, a)
            if (!resultat.isFinite()) {
                mostrarError(R.string.error_generic)
                return
            }
            // Longitud: 4 decimals
            textResultat.text = String.format(Locale.US, "%.4f %s", resultat, SIMBOLS[a])
        } catch (e: Exception) {
            mostrarError(R.string.error_generic)
        }
    }

    private fun unitatOrigen(id: Int): Int? = when (id) {
        R.id.radioQuilometre -> QUILOMETRE
        R.id.radioMilla -> MILLA
        R.id.radioYarda -> YARDA
        else -> null
    }

    private fun unitatDesti(id: Int): Int? = when (id) {
        R.id.radioQuilometreA -> QUILOMETRE
        R.id.radioMillaA -> MILLA
        R.id.radioYardaA -> YARDA
        else -> null
    }

    private fun mostrarError(@StringRes missatge: Int) {
        Toast.makeText(this, missatge, Toast.LENGTH_SHORT).show()
    }

    companion object {
        const val QUILOMETRE = 0
        const val MILLA = 1
        const val YARDA = 2

        val SIMBOLS = arrayOf("km", "mi", "yd")

        /** FACTORS[de][a]: quant val 1 unitat "de" en unitats "a". */
        private val FACTORS = arrayOf(
            //               km          mi            yd
            doubleArrayOf(1.0,       0.621371,     1093.6133), // de km
            doubleArrayOf(1.60934,   1.0,          1760.0),    // de mi
            doubleArrayOf(0.0009144, 0.000568182,  1.0)        // de yd
        )

        fun calcular(valor: Double, de: Int, a: Int): Double = valor * FACTORS[de][a]
    }
}
