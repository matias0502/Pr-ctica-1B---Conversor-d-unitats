package cat.institut.dam.conversor

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

/**
 * Pantalla d'inici: menú amb tres botons.
 *
 * Cada botó obre una conversora amb un Intent EXPLÍCIT (indiquem la classe
 * exacta de destí). Android apila la nova Activity a sobre del menú, i per
 * això el botó Enrere hi torna sempre.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val botoTemperatura = findViewById<Button>(R.id.botoTemperatura)
        val botoLongitud = findViewById<Button>(R.id.botoLongitud)
        val botoMassa = findViewById<Button>(R.id.botoMassa)

        botoTemperatura.setOnClickListener {
            // 1) Es crea l'Intent: des d'aquesta Activity vull obrir TemperaturaActivity
            val intent = Intent(this, TemperaturaActivity::class.java)
            // 2) S'engega: Android crea l'Activity i la posa al damunt de la pila
            startActivity(intent)
        }

        botoLongitud.setOnClickListener {
            val intent = Intent(this, LongitudActivity::class.java)
            startActivity(intent)
        }

        botoMassa.setOnClickListener {
            val intent = Intent(this, MassaActivity::class.java)
            startActivity(intent)
        }
    }
}
