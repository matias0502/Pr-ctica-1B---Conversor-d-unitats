package cat.institut.dam.conversor

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

/**
 * Conversor de massa: quilogram, lliura i unça.
 *
 * Mateixa estratègia que a longitud: taula de factors directes de l'enunciat,
 *   resultat = valor × FACTORS[origen][destí]
 */
class MassaActivity : AppCompatActivity() {

    private lateinit var editValor: EditText
    private lateinit var radioGroupDe: RadioGroup
    private lateinit var radioGroupA: RadioGroup
    private lateinit var textResultat: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_massa)

        editValor = findViewById(R.id.editValor)
        radioGroupDe = findViewById(R.id.radioGroupDe)
        radioGroupA = findViewById(R.id.radioGroupA)
        textResultat = findViewById(R.id.textResultat)

        findViewById<Button>(R.id.botoConvertir).setOnClickListener { convertir() }
    }

    private fun convertir() {
        val text = editValor.text.toString().trim()
        if (text.isEmpty()) {
            mostrarError(R.string.error_buid)
            return
        }

        val valor = text.toDoubleOrNull()
        if (valor == null) {
            mostrarError(R.string.error_numeric)
            return
        }

        val de = unitatOrigen(radioGroupDe.checkedRadioButtonId)
        val a = unitatDesti(radioGroupA.checkedRadioButtonId)
        if (de == null || a == null) {
            mostrarError(R.string.error_generic)
            return
        }

        if (de == a) {
            mostrarError(R.string.error_unitats)
            return
        }

        try {
            val resultat = calcular(valor, de, a)
            if (!resultat.isFinite()) {
                mostrarError(R.string.error_generic)
                return
            }
            // Massa: 4 decimals
            textResultat.text = String.format(Locale.US, "%.4f %s", resultat, SIMBOLS[a])
        } catch (e: Exception) {
            mostrarError(R.string.error_generic)
        }
    }

    private fun unitatOrigen(id: Int): Int? = when (id) {
        R.id.radioQuilogram -> QUILOGRAM
        R.id.radioLliura -> LLIURA
        R.id.radioUnca -> UNCA
        else -> null
    }

    private fun unitatDesti(id: Int): Int? = when (id) {
        R.id.radioQuilogramA -> QUILOGRAM
        R.id.radioLliuraA -> LLIURA
        R.id.radioUncaA -> UNCA
        else -> null
    }

    private fun mostrarError(@StringRes missatge: Int) {
        Toast.makeText(this, missatge, Toast.LENGTH_SHORT).show()
    }

    companion object {
        const val QUILOGRAM = 0
        const val LLIURA = 1
        const val UNCA = 2

        val SIMBOLS = arrayOf("kg", "lb", "oz")

        /** FACTORS[de][a]: quant val 1 unitat "de" en unitats "a". */
        private val FACTORS = arrayOf(
            //               kg          lb         oz
            doubleArrayOf(1.0,       2.20462,   35.27396), // de kg
            doubleArrayOf(0.453592,  1.0,       16.0),     // de lb
            doubleArrayOf(0.0283495, 0.0625,    1.0)       // de oz
        )

        fun calcular(valor: Double, de: Int, a: Int): Double = valor * FACTORS[de][a]
    }
}
