package cat.institut.dam.conversor

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

/**
 * Conversor de temperatura: Celsius, Fahrenheit i Kelvin.
 *
 * Estratègia: tot passa per la unitat base (Celsius).
 *   origen --aCelsius()--> °C --deCelsius()--> destí
 * Així només calen 3 fórmules d'entrada i 3 de sortida en lloc de 6 parelles.
 * (Les fórmules de temperatura són exactes, de manera que passar per la base
 * no introdueix cap error d'arrodoniment.)
 */
class TemperaturaActivity : AppCompatActivity() {

    private lateinit var editValor: EditText
    private lateinit var radioGroupDe: RadioGroup
    private lateinit var radioGroupA: RadioGroup
    private lateinit var textResultat: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_temperatura)

        editValor = findViewById(R.id.editValor)
        radioGroupDe = findViewById(R.id.radioGroupDe)
        radioGroupA = findViewById(R.id.radioGroupA)
        textResultat = findViewById(R.id.textResultat)

        findViewById<Button>(R.id.botoConvertir).setOnClickListener { convertir() }
    }

    private fun convertir() {
        // 1. Llegir el valor
        val text = editValor.text.toString().trim()

        // 2. Validar que no és buit
        if (text.isEmpty()) {
            mostrarError(R.string.error_buid)
            return
        }

        // 3. Convertir a Double de manera segura (null si no és un número)
        val valor = text.toDoubleOrNull()
        if (valor == null) {
            mostrarError(R.string.error_numeric)
            return
        }

        // 4. Llegir les unitats seleccionades (-1 si no n'hi ha cap)
        val de = unitatOrigen(radioGroupDe.checkedRadioButtonId)
        val a = unitatDesti(radioGroupA.checkedRadioButtonId)
        if (de == null || a == null) {
            mostrarError(R.string.error_generic)
            return
        }

        // 5. Comprovar que no són la mateixa unitat
        if (de == a) {
            mostrarError(R.string.error_unitats)
            return
        }

        // 6 i 7. Calcular i mostrar el resultat (2 decimals, punt decimal sempre)
        try {
            val resultat = calcular(valor, de, a)
            if (!resultat.isFinite()) {
                mostrarError(R.string.error_generic)
                return
            }
            textResultat.text = String.format(Locale.US, "%.2f %s", resultat, SIMBOLS[a])
        } catch (e: Exception) {
            mostrarError(R.string.error_generic)
        }
    }

    /** Tradueix l'id del RadioButton d'origen a un índex d'unitat. */
    private fun unitatOrigen(id: Int): Int? = when (id) {
        R.id.radioCelsius -> CELSIUS
        R.id.radioFahrenheit -> FAHRENHEIT
        R.id.radioKelvin -> KELVIN
        else -> null // -1: cap opció marcada
    }

    /** Tradueix l'id del RadioButton de destí a un índex d'unitat. */
    private fun unitatDesti(id: Int): Int? = when (id) {
        R.id.radioCelsiusA -> CELSIUS
        R.id.radioFahrenheitA -> FAHRENHEIT
        R.id.radioKelvinA -> KELVIN
        else -> null
    }

    private fun mostrarError(@StringRes missatge: Int) {
        Toast.makeText(this, missatge, Toast.LENGTH_SHORT).show()
    }

    companion object {
        const val CELSIUS = 0
        const val FAHRENHEIT = 1
        const val KELVIN = 2

        /** Símbols internacionals: no es tradueixen. */
        val SIMBOLS = arrayOf("°C", "°F", "K")

        /** De qualsevol unitat a la unitat base (Celsius). */
        fun aCelsius(valor: Double, unitat: Int): Double = when (unitat) {
            CELSIUS -> valor
            FAHRENHEIT -> (valor - 32.0) * 5.0 / 9.0
            KELVIN -> valor - 273.15
            else -> throw IllegalArgumentException("Unitat desconeguda: $unitat")
        }

        /** De la unitat base (Celsius) a qualsevol unitat. */
        fun deCelsius(celsius: Double, unitat: Int): Double = when (unitat) {
            CELSIUS -> celsius
            FAHRENHEIT -> celsius * 9.0 / 5.0 + 32.0
            KELVIN -> celsius + 273.15
            else -> throw IllegalArgumentException("Unitat desconeguda: $unitat")
        }

        fun calcular(valor: Double, de: Int, a: Int): Double =
            deCelsius(aCelsius(valor, de), a)
    }
}
